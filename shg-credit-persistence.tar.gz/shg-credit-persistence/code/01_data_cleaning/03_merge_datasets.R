# ==============================================================================
# 03_merge_datasets.R
# Purpose: Merge CPHS and NRLM data; construct outcome variables
# Author: Aarushi Gupta
# Date: April 2026
# ==============================================================================

library(tidyverse)
library(data.table)

# ==============================================================================
# LOAD PREPARED DATA
# ==============================================================================

cphs_clean <- fread("data/processed/cphs_rural_banked_female.csv") %>%
  as_tibble()

nrlm_clean <- fread("data/processed/shg_intensity_state_year.csv") %>%
  as_tibble()

cat("CPHS rows:", nrow(cphs_clean), "\n")
cat("NRLM rows:", nrow(nrlm_clean), "\n")

# ==============================================================================
# MERGE CPHS + NRLM
# ==============================================================================

# Rename state in nrlm to match cphs
nrlm_clean <- nrlm_clean %>%
  rename(state = state)

# Merge on state and year
analysis_df <- cphs_clean %>%
  left_join(
    nrlm_clean %>% select(state, year, shg_intensity, state_population),
    by = c("state", "year")
  )

# Check for missing SHG intensity
cat("\nMissing SHG intensity after merge:", sum(is.na(analysis_df$shg_intensity)), "\n")

# ==============================================================================
# CONSTRUCT OUTCOME VARIABLES
# ==============================================================================

# Create household-wave panel structure
analysis_df <- analysis_df %>%
  arrange(household_id, year, wave) %>%
  group_by(household_id) %>%
  mutate(
    # Lag borrowing variables
    formal_lag = lag(borrow_formal),
    informal_lag = lag(informal_lag),
    any_lag = lag(borrow_any),
    
    # Construct outcome: AnyFormalBorrow
    # = 1 if borrowed formal in current wave, 0 otherwise
    any_formal_borrow = borrow_formal,
    
    # Construct outcome: RepeatFormalBorrow
    # = 1 if borrowed formal in BOTH current wave AND previous wave
    # = 0 if borrowed in current wave but ONLY informal in current wave
    # = NA (missing) if did not borrow in current wave
    repeat_formal_borrow = ifelse(
      is.na(formal_lag),  # First wave or new entrant
      NA,
      ifelse(borrow_formal == 1 & formal_lag == 1,
        1,  # Borrowed formal in both waves
        ifelse(borrow_formal == 1 & formal_lag == 0,
          0,  # Borrowed formal in current but not previous
          NA  # Did not borrow formal in current wave
        )
      )
    ),
    
    # Alternative coding: non-borrowers in current wave = 0
    repeat_formal_borrow_inclusive = ifelse(
      is.na(formal_lag),
      NA,
      ifelse(borrow_formal == 1 & formal_lag == 1,
        1,
        0  # All other cases = 0
      )
    )
  ) %>%
  ungroup()

# ==============================================================================
# SAMPLE CONSTRUCTION FOR REGRESSION
# ==============================================================================

# Create "borrowing-wave" indicator: household borrowed in wave t
analysis_df <- analysis_df %>%
  mutate(
    is_active_borrower = ifelse(borrow_any == 1, 1, 0)
  )

# Restricting regression sample: only consecutive-wave household pairs
# (i.e., households present in both t and t-1)
analysis_df <- analysis_df %>%
  group_by(household_id) %>%
  mutate(
    has_prior_wave = !is.na(lag(year))
  ) %>%
  filter(has_prior_wave == TRUE | row_number() > 1) %>%
  ungroup()

cat("\nSample sizes for regression:\n")
cat("Full analysis sample:", nrow(analysis_df), "\n")
cat("With non-missing outcomes:", sum(!is.na(analysis_df$any_formal_borrow)), "\n")
cat("RepeatFormalBorrow (conditional, non-borrowers = NA):",
    sum(!is.na(analysis_df$repeat_formal_borrow)), "\n")
cat("RepeatFormalBorrow (inclusive, non-borrowers = 0):",
    sum(!is.na(analysis_df$repeat_formal_borrow_inclusive)), "\n")

# ==============================================================================
# OUTCOME VARIABLE QUALITY CHECKS
# ==============================================================================

cat("\n=== AnyFormalBorrow ===\n")
print(table(analysis_df$any_formal_borrow, useNA = "always"))

cat("\n=== RepeatFormalBorrow (Conditional, Non-borrowers = NA) ===\n")
print(table(analysis_df$repeat_formal_borrow, useNA = "always"))

cat("\n=== RepeatFormalBorrow (Inclusive, Non-borrowers = 0) ===\n")
print(table(analysis_df$repeat_formal_borrow_inclusive, useNA = "always"))

# Outcome means
cat("\n=== OUTCOME MEANS ===\n")
print(analysis_df %>%
  summarise(
    mean_any_formal = mean(any_formal_borrow, na.rm = TRUE),
    mean_repeat_formal_cond = mean(repeat_formal_borrow, na.rm = TRUE),
    mean_repeat_formal_incl = mean(repeat_formal_borrow_inclusive, na.rm = TRUE),
    n_repeat_formal_cond = sum(!is.na(repeat_formal_borrow)),
    n_repeat_formal_incl = sum(!is.na(repeat_formal_borrow_inclusive))
  ))

# ==============================================================================
# OUTCOME TRENDS BY YEAR
# ==============================================================================

cat("\n=== OUTCOME TRENDS BY YEAR ===\n")
outcome_trends <- analysis_df %>%
  group_by(year) %>%
  summarise(
    any_formal = mean(any_formal_borrow, na.rm = TRUE) * 100,
    repeat_formal = mean(repeat_formal_borrow, na.rm = TRUE) * 100,
    n_obs = n(),
    n_active = sum(is_active_borrower)
  )

print(outcome_trends)

# ==============================================================================
# TREATMENT VARIABLE QUALITY
# ==============================================================================

cat("\n=== TREATMENT VARIABLE: SHG INTENSITY ===\n")
print(analysis_df %>%
  summarise(
    mean_intensity = mean(shg_intensity, na.rm = TRUE),
    sd_intensity = sd(shg_intensity, na.rm = TRUE),
    min_intensity = min(shg_intensity, na.rm = TRUE),
    max_intensity = max(shg_intensity, na.rm = TRUE),
    missing = sum(is.na(shg_intensity))
  ))

# ==============================================================================
# CONTROL VARIABLE SUMMARY
# ==============================================================================

cat("\n=== CONTROL VARIABLES ===\n")
print(analysis_df %>%
  summarise(
    mean_income = mean(log_income, na.rm = TRUE),
    mean_age = mean(age, na.rm = TRUE),
    mean_educ = mean(education, na.rm = TRUE),
    pct_female_headed = mean(female_headed, na.rm = TRUE) * 100,
    mean_hh_size = mean(household_size, na.rm = TRUE),
    mean_assets = mean(asset_index, na.rm = TRUE)
  ))

# ==============================================================================
# SAVE FINAL ANALYSIS DATASET
# ==============================================================================

# Select key variables for regression
analysis_df_final <- analysis_df %>%
  select(
    household_id, state, district, year, wave,
    shg_intensity, state_population,
    any_formal_borrow, repeat_formal_borrow, repeat_formal_borrow_inclusive,
    borrow_formal, borrow_informal, borrow_any,
    log_income, age, education, female_headed,
    asset_index, household_size,
    has_lic, has_pf,
    occ_student, occ_farming, occ_wage_labor, occ_homemaker
  )

fwrite(analysis_df_final, "data/processed/analysis_dataset.csv")
cat("\n✓ Final analysis dataset saved to: data/processed/analysis_dataset.csv\n")

# ==============================================================================
# DATASET DOCUMENTATION
# ==============================================================================

dataset_doc <- data.frame(
  Variable = names(analysis_df_final),
  Type = sapply(analysis_df_final, class),
  N_Missing = sapply(analysis_df_final, function(x) sum(is.na(x))),
  Mean = sapply(analysis_df_final, function(x) mean(x, na.rm = TRUE)),
  SD = sapply(analysis_df_final, function(x) sd(x, na.rm = TRUE))
)

fwrite(dataset_doc, "docs/data_codebook.csv")
cat("✓ Data codebook saved to: docs/data_codebook.csv\n")

cat("\n=== MERGE COMPLETE ===\n")
cat("Analysis dataset ready for regression.\n")
cat("Dimensions:", nrow(analysis_df_final), "rows x", ncol(analysis_df_final), "columns\n")
