# ==============================================================================
# 02_nrlm_prepare.R
# Purpose: Prepare NRLM SHG data and construct treatment variable
# Author: Aarushi Gupta
# Date: April 2026
# ==============================================================================

library(tidyverse)
library(data.table)

# ==============================================================================
# LOAD NRLM MIS DATA
# ==============================================================================

# Load state-year SHG counts from NRLM MIS portal
# Source: https://nrlm.gov.in/
nrlm_raw <- fread("data/raw/nrlm_shg_data.csv") %>%
  as_tibble()

head(nrlm_raw)

# ==============================================================================
# CONSTRUCT TREATMENT VARIABLE: SHG INTENSITY
# ==============================================================================

# Load 2011 Census state population data
# [User can obtain from Census of India official website]
census_population <- fread("data/raw/census_2011_state_population.csv") %>%
  as_tibble()

# Merge NRLM counts with census population
nrlm_clean <- nrlm_raw %>%
  left_join(census_population, by = "state") %>%
  # Construct treatment: SHGs per 1,000 state population
  mutate(
    shg_intensity = (total_shgs_mobilized / state_population) * 1000,
    log_state_population = log(state_population)
  ) %>%
  select(
    state, year, total_shgs_mobilized, shg_intensity,
    state_population, log_state_population
  ) %>%
  # Arrange for easy verification
  arrange(state, year)

# ==============================================================================
# QUALITY CHECKS ON TREATMENT VARIABLE
# ==============================================================================

cat("\n=== SHG INTENSITY SUMMARY STATISTICS ===\n")
print(nrlm_clean %>%
  summarise(
    mean_shg_intensity = mean(shg_intensity, na.rm = TRUE),
    sd_shg_intensity = sd(shg_intensity, na.rm = TRUE),
    min_shg_intensity = min(shg_intensity, na.rm = TRUE),
    max_shg_intensity = max(shg_intensity, na.rm = TRUE),
    p25 = quantile(shg_intensity, 0.25, na.rm = TRUE),
    p50 = quantile(shg_intensity, 0.50, na.rm = TRUE),
    p75 = quantile(shg_intensity, 0.75, na.rm = TRUE)
  ))

# By year
cat("\n=== SHG INTENSITY BY YEAR ===\n")
print(nrlm_clean %>%
  group_by(year) %>%
  summarise(
    mean_intensity = mean(shg_intensity, na.rm = TRUE),
    sd_intensity = sd(shg_intensity, na.rm = TRUE),
    n_states = n_distinct(state)
  ))

# Top and bottom states in 2022
cat("\n=== TOP 10 STATES BY SHG INTENSITY (2022) ===\n")
print(nrlm_clean %>%
  filter(year == 2022) %>%
  arrange(desc(shg_intensity)) %>%
  head(10) %>%
  select(state, shg_intensity, total_shgs_mobilized))

cat("\n=== BOTTOM 10 STATES BY SHG INTENSITY (2022) ===\n")
print(nrlm_clean %>%
  filter(year == 2022) %>%
  arrange(shg_intensity) %>%
  head(10) %>%
  select(state, shg_intensity, total_shgs_mobilized))

# ==============================================================================
# WITHIN-STATE VARIATION (KEY FOR IDENTIFICATION)
# ==============================================================================

# Calculate within-state standard deviation of SHG intensity
within_state_var <- nrlm_clean %>%
  group_by(state) %>%
  mutate(
    mean_intensity_state = mean(shg_intensity, na.rm = TRUE),
    deviation = shg_intensity - mean_intensity_state
  ) %>%
  ungroup() %>%
  summarise(
    within_state_sd = sd(deviation, na.rm = TRUE),
    total_sd = sd(shg_intensity, na.rm = TRUE),
    ratio = within_state_sd / total_sd
  )

cat("\n=== IDENTIFICATION VARIATION ===\n")
cat("Within-state SD of SHG intensity: ", within_state_var$within_state_sd, "\n")
cat("Total SD of SHG intensity: ", within_state_var$total_sd, "\n")
cat("Ratio (within/total): ", within_state_var$ratio, "\n")
cat("Interpretation: The TWFE specification uses about", 
    round(within_state_var$ratio * 100, 1), 
    "% of the variation in SHG intensity\n")

# ==============================================================================
# PARALLEL TRENDS CHECK (VISUAL)
# ==============================================================================

# Plot SHG trajectories for selected states (visual inspection)
example_states <- c("Andhra Pradesh", "Bihar", "Uttar Pradesh", "Telangana", "Madhya Pradesh")

cat("\nPlotting SHG intensity trajectories for key states...\n")
nrlm_clean %>%
  filter(state %in% example_states) %>%
  ggplot(aes(x = year, y = shg_intensity, color = state, group = state)) +
  geom_line(size = 1) +
  geom_point(size = 2) +
  labs(
    title = "SHG Intensity Trajectories, Selected States (2017-2022)",
    x = "Year",
    y = "SHGs per 1,000 state population",
    color = "State"
  ) +
  theme_minimal() +
  theme(legend.position = "bottom")

ggsave("output/figures/shg_intensity_trajectories.png", width = 8, height = 5)

# ==============================================================================
# SAVE PROCESSED NRLM DATA
# ==============================================================================

fwrite(nrlm_clean, "data/processed/shg_intensity_state_year.csv")
cat("\nProcessed NRLM data saved to: data/processed/shg_intensity_state_year.csv\n")

# Save within-state variation summary
fwrite(as.data.frame(within_state_var), "output/identification_variation.csv")
cat("Identification variation summary saved.\n")
