# ==============================================================================
# 01_cphs_prepare.R
# Purpose: Load CPHS data and restrict to rural banked women sample
# Author: Aarushi Gupta
# Date: April 2026
# ==============================================================================

library(tidyverse)
library(data.table)

# Load CPHS data (all waves, 2017-2022)
# [User to modify path based on their CPHS data location]
cphs_raw <- fread("data/raw/cphs_2017_2022.csv")

# ==============================================================================
# SAMPLE RESTRICTION PIPELINE
# ==============================================================================

# 1. RESTRICT TO RURAL HOUSEHOLDS
cphs_rural <- cphs_raw %>%
  filter(rural == 1) %>%
  mutate(restriction_step = "Rural households")

cat("Full CPHS universe: ", nrow(cphs_raw), "\n")
cat("After rural restriction: ", nrow(cphs_rural), "\n")

# 2. RESTRICT TO FEMALE MEMBERS
cphs_female <- cphs_rural %>%
  filter(female == 1) %>%
  mutate(restriction_step = "Female members")

cat("After female restriction: ", nrow(cphs_female), "\n")

# 3. RESTRICT TO WOMEN WITH BANK ACCOUNTS
cphs_banked <- cphs_female %>%
  filter(has_bank_account == 1) %>%
  mutate(restriction_step = "Has bank account")

cat("After bank account restriction: ", nrow(cphs_banked), "\n")

# ==============================================================================
# KEY VARIABLES: BORROWING AND DEMOGRAPHICS
# ==============================================================================

cphs_clean <- cphs_banked %>%
  # Borrowing source variables
  mutate(
    # Borrowing from organized sources (formal)
    borrow_formal = ifelse(
      borrow_bank == 1 | borrow_nbfc == 1 | borrow_shg == 1 | 
      borrow_mfi == 1 | borrow_credit_card == 1,
      1, 0
    ),
    # Borrowing from unorganized sources (informal)
    borrow_informal = ifelse(
      borrow_moneylender == 1 | borrow_trader == 1 | 
      borrow_friends == 1 | borrow_relatives == 1,
      1, 0
    ),
    # Any borrowing
    borrow_any = ifelse(borrow_formal == 1 | borrow_informal == 1, 1, 0),
    # SHG borrowing specifically (for later analysis)
    borrow_shg_only = borrow_shg
  ) %>%
  # Demographic and control variables
  mutate(
    log_income = log(monthly_income + 1),
    age = female_age,
    education = female_years_schooling,
    female_headed = ifelse(household_head == "female", 1, 0),
    # Asset proxies
    has_lic = ifelse(lic_policy == 1, 1, 0),
    has_pf = ifelse(provident_fund == 1, 1, 0),
    # Occupation dummies
    occ_student = ifelse(occupation_group == "Student", 1, 0),
    occ_farming = ifelse(occupation_group %in% c("Small farmer", "Organized farmer"), 1, 0),
    occ_wage_labor = ifelse(occupation_group == "Wage laborer", 1, 0),
    occ_homemaker = ifelse(occupation_group == "Homemaker", 1, 0),
    # Asset index (simple sum; can be improved with PCA)
    asset_index = has_lic + has_pf
  ) %>%
  select(
    # Identifiers
    household_id, year, wave, state, district,
    # Outcomes
    borrow_formal, borrow_informal, borrow_any,
    borrow_bank, borrow_shg, borrow_mfi, borrow_nbfc,
    borrow_moneylender, borrow_trader, borrow_friends,
    # Controls
    log_income, age, education, female_headed, asset_index,
    has_lic, has_pf,
    occ_student, occ_farming, occ_wage_labor, occ_homemaker,
    household_size
  )

# ==============================================================================
# CHECK FOR MISSING VALUES AND DATA QUALITY
# ==============================================================================

# Borrowing outcome missingness
cat("\n=== BORROWING OUTCOME MISSINGNESS ===\n")
print(cphs_clean %>%
  summarise(
    missing_formal = sum(is.na(borrow_formal)) / n(),
    missing_informal = sum(is.na(borrow_informal)) / n(),
    missing_any = sum(is.na(borrow_any)) / n()
  ))

# Control variable missingness
cat("\n=== CONTROL VARIABLE MISSINGNESS ===\n")
print(cphs_clean %>%
  summarise(
    missing_income = sum(is.na(log_income)) / n(),
    missing_age = sum(is.na(age)) / n(),
    missing_education = sum(is.na(education)) / n(),
    missing_household_size = sum(is.na(household_size)) / n()
  ))

# Remove rows with missing key variables
cphs_clean <- cphs_clean %>%
  filter(!is.na(borrow_formal), !is.na(borrow_informal)) %>%
  filter(!is.na(log_income), !is.na(age), !is.na(education))

cat("\nFinal sample after removing missing: ", nrow(cphs_clean), "\n")

# ==============================================================================
# SUMMARY STATISTICS BY YEAR
# ==============================================================================

cat("\n=== SAMPLE SIZE BY YEAR ===\n")
print(cphs_clean %>%
  group_by(year) %>%
  summarise(
    n_obs = n(),
    n_households = n_distinct(household_id),
    pct_borrow_formal = mean(borrow_formal, na.rm = TRUE) * 100,
    pct_borrow_informal = mean(borrow_informal, na.rm = TRUE) * 100
  ))

# ==============================================================================
# SAVE PROCESSED DATA
# ==============================================================================

fwrite(cphs_clean, "data/processed/cphs_rural_banked_female.csv")
cat("\nProcessed CPHS data saved to: data/processed/cphs_rural_banked_female.csv\n")

# Store sample size details for documentation
sample_funnel <- data.frame(
  stage = c(
    "Full CPHS universe",
    "Rural households",
    "Female members",
    "Has bank account",
    "Final sample (non-missing)"
  ),
  n_obs = c(
    nrow(cphs_raw),
    nrow(cphs_rural),
    nrow(cphs_female),
    nrow(cphs_banked),
    nrow(cphs_clean)
  )
)

fwrite(sample_funnel, "output/sample_funnel.csv")
cat("Sample restriction funnel saved.\n")
