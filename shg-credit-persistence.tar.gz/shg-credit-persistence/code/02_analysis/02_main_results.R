# ==============================================================================
# 02_main_results.R
# Purpose: Run TWFE regressions for AnyFormalBorrow and RepeatFormalBorrow
# Author: Aarushi Gupta
# Date: April 2026
# ==============================================================================

library(tidyverse)
library(data.table)
library(fixest)        # For TWFE estimation
library(sandwich)      # For robust standard errors
library(broom)         # For clean output

# ==============================================================================
# LOAD MERGED ANALYSIS DATASET
# ==============================================================================

analysis_df <- fread("data/processed/analysis_dataset.csv") %>%
  as_tibble()

# Quick check
cat("Analysis dataset dimensions:", nrow(analysis_df), "x", ncol(analysis_df), "\n")
cat("Unique households:", n_distinct(analysis_df$household_id), "\n")
cat("Years covered:", min(analysis_df$year), "to", max(analysis_df$year), "\n")

# ==============================================================================
# OUTCOME 1: AnyFormalBorrow (ENTRY MARGIN)
# ==============================================================================

cat("\n==================== AnyFormalBorrow (Entry) ====================\n")

# Specification 1: Bivariate (SHG intensity only, no controls, no FE)
model_entry_1 <- feols(
  any_formal_borrow ~ shg_intensity,
  data = analysis_df,
  se = "cluster",
  cluster = ~state
)

# Specification 2: Add household controls
model_entry_2 <- feols(
  any_formal_borrow ~ shg_intensity + log_income + age + education +
    female_headed + asset_index + household_size,
  data = analysis_df,
  se = "cluster",
  cluster = ~state
)

# Specification 3: PREFERRED - Add district and year FE
model_entry_3 <- feols(
  any_formal_borrow ~ shg_intensity + log_income + age + education +
    female_headed + asset_index + household_size |
    district + year,
  data = analysis_df,
  se = "cluster",
  cluster = ~state
)

# Specification 4: Logit with state and year FE (for binary outcome robustness)
# Note: logit with many FE can be computationally intensive
analysis_df$state_num <- as.numeric(factor(analysis_df$state))
analysis_df$year_num <- as.numeric(factor(analysis_df$year))

model_entry_4 <- feglm(
  any_formal_borrow ~ shg_intensity + log_income + age + education +
    female_headed + asset_index + household_size +
    factor(state_num) + factor(year_num),
  data = analysis_df,
  family = binomial(link = "logit")
)

# Extract logit average marginal effects
logit_ame_entry <- marginal_effects(model_entry_4, "shg_intensity")

cat("\nEntry Margin - Model 1 (Bivariate):\n")
print(model_entry_1)

cat("\nEntry Margin - Model 2 (+ Controls):\n")
print(model_entry_2)

cat("\nEntry Margin - Model 3 (+ FE, PREFERRED):\n")
print(model_entry_3)

cat("\nEntry Margin - Model 4 (Logit AME):\n")
print(summary(logit_ame_entry))

# ==============================================================================
# OUTCOME 2: RepeatFormalBorrow (PERSISTENCE MARGIN)
# ==============================================================================

cat("\n==================== RepeatFormalBorrow (Persistence) ====================\n")

# Specification 1: Bivariate
model_persist_1 <- feols(
  repeat_formal_borrow ~ shg_intensity,
  data = analysis_df %>% filter(!is.na(repeat_formal_borrow)),
  se = "cluster",
  cluster = ~state
)

# Specification 2: Add household controls
model_persist_2 <- feols(
  repeat_formal_borrow ~ shg_intensity + log_income + age + education +
    female_headed + asset_index + household_size,
  data = analysis_df %>% filter(!is.na(repeat_formal_borrow)),
  se = "cluster",
  cluster = ~state
)

# Specification 3: PREFERRED - Add district and year FE
model_persist_3 <- feols(
  repeat_formal_borrow ~ shg_intensity + log_income + age + education +
    female_headed + asset_index + household_size |
    district + year,
  data = analysis_df %>% filter(!is.na(repeat_formal_borrow)),
  se = "cluster",
  cluster = ~state
)

# Specification 4: Logit
model_persist_4 <- feglm(
  repeat_formal_borrow ~ shg_intensity + log_income + age + education +
    female_headed + asset_index + household_size +
    factor(state_num) + factor(year_num),
  data = analysis_df %>% filter(!is.na(repeat_formal_borrow)),
  family = binomial(link = "logit")
)

logit_ame_persist <- marginal_effects(model_persist_4, "shg_intensity")

cat("\nPersistence Margin - Model 1 (Bivariate):\n")
print(model_persist_1)

cat("\nPersistence Margin - Model 2 (+ Controls):\n")
print(model_persist_2)

cat("\nPersistence Margin - Model 3 (+ FE, PREFERRED):\n")
print(model_persist_3)

cat("\nPersistence Margin - Model 4 (Logit AME):\n")
print(summary(logit_ame_persist))

# ==============================================================================
# SIDE-BY-SIDE COMPARISON TABLE
# ==============================================================================

# Create summary table comparing entry vs. persistence
comparison_table <- tibble(
  Outcome = c("AnyFormalBorrow", "AnyFormalBorrow", "AnyFormalBorrow", "AnyFormalBorrow",
              "RepeatFormalBorrow", "RepeatFormalBorrow", "RepeatFormalBorrow", "RepeatFormalBorrow"),
  Specification = c("(1) Bivariate", "(2) + Controls", "(3) + FE", "(4) Logit",
                    "(1) Bivariate", "(2) + Controls", "(3) + FE", "(4) Logit"),
  Coefficient = c(
    coef(model_entry_1)["shg_intensity"],
    coef(model_entry_2)["shg_intensity"],
    coef(model_entry_3)["shg_intensity"],
    logit_ame_entry$estimate,
    coef(model_persist_1)["shg_intensity"],
    coef(model_persist_2)["shg_intensity"],
    coef(model_persist_3)["shg_intensity"],
    logit_ame_persist$estimate
  ),
  SE = c(
    se(model_entry_1)["shg_intensity"],
    se(model_entry_2)["shg_intensity"],
    se(model_entry_3)["shg_intensity"],
    logit_ame_entry$std.error,
    se(model_persist_1)["shg_intensity"],
    se(model_persist_2)["shg_intensity"],
    se(model_persist_3)["shg_intensity"],
    logit_ame_persist$std.error
  ),
  p_value = c(
    pvalue(model_entry_1)["shg_intensity"],
    pvalue(model_entry_2)["shg_intensity"],
    pvalue(model_entry_3)["shg_intensity"],
    logit_ame_entry$p.value,
    pvalue(model_persist_1)["shg_intensity"],
    pvalue(model_persist_2)["shg_intensity"],
    pvalue(model_persist_3)["shg_intensity"],
    logit_ame_persist$p.value
  )
)

cat("\n==================== COMPARISON TABLE ====================\n")
print(comparison_table)

# Save comparison table
fwrite(comparison_table, "output/tables/table_2_main_results.csv")

# ==============================================================================
# MODEL FIT AND DIAGNOSTICS
# ==============================================================================

cat("\n==================== MODEL FIT DIAGNOSTICS ====================\n")

cat("\nEntry Margin (Model 3, preferred):\n")
cat("R-squared:", r2(model_entry_3), "\n")
cat("N observations:", nobs(model_entry_3), "\n")
cat("N clusters (states):", length(unique(analysis_df$state)), "\n")

cat("\nPersistence Margin (Model 3, preferred):\n")
cat("R-squared:", r2(model_persist_3), "\n")
cat("N observations:", nobs(model_persist_3), "\n")
cat("N clusters (states):", length(unique(analysis_df %>% 
  filter(!is.na(repeat_formal_borrow)) %>% pull(state))), "\n")

# ==============================================================================
# KEY RESULT: SIGN FLIP INTERPRETATION
# ==============================================================================

coef_entry <- coef(model_entry_3)["shg_intensity"]
coef_persist <- coef(model_persist_3)["shg_intensity"]

cat("\n==================== INTERPRETATION ====================\n")
cat("Entry coefficient (AnyFormalBorrow):", round(coef_entry, 4), "\n")
cat("Persistence coefficient (RepeatFormalBorrow):", round(coef_persist, 4), "\n")
cat("\nInterpretation:\n")
cat("- SHG intensity has near-zero effect on entry into formal borrowing\n")
cat("- But shows NEGATIVE effect on repeat formal borrowing\n")
cat("- This suggests: SHG expansion shifts credit composition (bank → SHG)\n")
cat("  rather than deepen sustained engagement with banks\n")
