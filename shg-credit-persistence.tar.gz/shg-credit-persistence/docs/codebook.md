# Data Codebook

## CPHS Variables

### Identifiers
- **household_id**: Unique household identifier
- **state**: State of residence (string)
- **district**: District of residence (string)
- **year**: Survey year (2017–2022)
- **wave**: Survey wave within year (1, 2, or 3)

### Primary Outcomes

#### AnyFormalBorrow
- **Type**: Binary (0/1)
- **Definition**: 1 if household reports any borrowing from organized sources in survey wave t; 0 otherwise
- **Organized sources**: Banks, RRBs, cooperative banks, MFIs, SHGs with bank linkage, credit cards
- **Sample**: All households in wave t

#### RepeatFormalBorrow
- **Type**: Binary (0/1, with NAs for non-borrowers in wave t)
- **Definition**: 
  - 1 if household borrowed from organized sources in BOTH wave t AND wave t-1
  - 0 if household borrowed in wave t BUT ONLY from informal sources in wave t
  - NA (missing) if household did not borrow from any source in wave t
- **Sample**: Consecutive household-wave pairs (active borrowers, n=84,681)
- **Interpretation**: Persistence in formal credit engagement

### Secondary Outcomes

#### Borrow_Formal
- **Type**: Binary (0/1)
- **Definition**: 1 if borrowed from organized sources in wave t
- **Components**: borrow_bank + borrow_nbfc + borrow_shg + borrow_mfi + borrow_credit_card

#### Borrow_Informal
- **Type**: Binary (0/1)
- **Definition**: 1 if borrowed from unorganized sources in wave t
- **Components**: borrow_moneylender + borrow_trader + borrow_friends + borrow_relatives

#### Borrow_Any
- **Type**: Binary (0/1)
- **Definition**: 1 if borrowed from any source (formal or informal) in wave t

#### Borrow_Bank
- **Type**: Binary (0/1)
- **Definition**: 1 if borrowed from bank in wave t

#### Borrow_SHG
- **Type**: Binary (0/1)
- **Definition**: 1 if borrowed from SHG with formal bank linkage in wave t

#### Borrow_MFI
- **Type**: Binary (0/1)
- **Definition**: 1 if borrowed from microfinance institution in wave t

#### Borrow_NBFC
- **Type**: Binary (0/1)
- **Definition**: 1 if borrowed from NBFC in wave t

#### Borrow_Moneylender
- **Type**: Binary (0/1)
- **Definition**: 1 if borrowed from informal moneylender in wave t

---

## NRLM Variables

### Treatment Variable

#### SHG_Intensity
- **Type**: Continuous, non-negative
- **Definition**: Number of Self-Help Groups mobilized per 1,000 state population
- **Calculation**: (total_shgs_mobilized / state_population_2011) * 1000
- **Source**: NRLM MIS portal (nrlm.gov.in)
- **Year Coverage**: 2017–2022
- **Geographic Level**: State-year
- **Range**: 0.06 (Delhi, 2017) to 16.8 (Andhra Pradesh, 2022)
- **Interpretation**: One additional SHG per 1,000 population

#### Total_SHGs_Mobilized
- **Type**: Count (integer)
- **Definition**: Total number of SHG groups mobilized in state-year
- **Source**: NRLM MIS portal

---

## Household Control Variables

### Demographic

#### Age
- **Type**: Continuous (integer, years)
- **Definition**: Age of female respondent
- **Source**: CPHS
- **Mean**: 36.0, SD: 17.3

#### Female_Years_Schooling (Education)
- **Type**: Continuous (integer, years)
- **Definition**: Highest educational attainment of female member
- **Source**: CPHS
- **Mean**: 8.5, SD: 3.8
- **Interpretation**: Roughly equivalent to primary school completion

#### Household_Size
- **Type**: Count (integer)
- **Definition**: Number of household members
- **Source**: CPHS
- **Mean**: 4.2 persons

#### Female_Headed
- **Type**: Binary (0/1)
- **Definition**: 1 if household head is female; 0 otherwise
- **Source**: CPHS

### Economic

#### Log_Income
- **Type**: Continuous (log-transformed)
- **Definition**: Natural log of monthly household income in Indian Rupees
- **Source**: CPHS
- **Units**: Rupees per month
- **Transformation**: log(income + 1) to handle zero incomes

#### Monthly_Income
- **Type**: Continuous (integer)
- **Definition**: Monthly household income in Rupees
- **Source**: CPHS
- **Currency**: Indian Rupees

### Asset Ownership

#### Has_LIC
- **Type**: Binary (0/1)
- **Definition**: 1 if any female member holds life insurance (LIC) policy
- **Source**: CPHS
- **Prevalence**: 26% of sample

#### Has_PF
- **Type**: Binary (0/1)
- **Definition**: 1 if any female member has provident fund account
- **Source**: CPHS
- **Prevalence**: 4% of sample

#### Asset_Index
- **Type**: Continuous (0–2)
- **Definition**: Simple sum of has_lic + has_pf
- **Interpretation**: Proxy for financial engagement beyond bank account

### Occupation

#### Occ_Student
- **Type**: Binary (0/1)
- **Definition**: 1 if female member's primary occupation is student
- **Prevalence**: 23.2% of sample

#### Occ_Farming
- **Type**: Binary (0/1)
- **Definition**: 1 if female member's primary occupation is farming (small or organized)
- **Prevalence**: 23.5% of sample

#### Occ_Wage_Labor
- **Type**: Binary (0/1)
- **Definition**: 1 if female member's primary occupation is wage labor
- **Prevalence**: 11.9% of sample

#### Occ_Homemaker
- **Type**: Binary (0/1)
- **Definition**: 1 if female member's primary occupation is homemaker
- **Prevalence**: 8.0% of sample

---

## Sample Restrictions

### Full CPHS Universe
- N observations: 3,327,983 individual-wave observations
- Years: 2017–2022
- Time period: September–December of each year

### Rural Households
- N observations: 1,176,897
- Restriction: rural == 1

### Female Members
- N observations: 564,284
- Restriction: female == 1

### With Bank Accounts (Analysis Sample)
- N observations: 459,406 individual-wave
- Unique households: 60,057
- Districts: 488
- States: 27
- Restriction: has_bank_account == 1

### Regression Sample (Repeat Borrowing)
- N consecutive-wave pairs: 84,681
- Unique households: 43,473
- Restriction: Non-missing borrowing source in both wave t and t-1
- Additional restriction: Active borrowers (borrowed in wave t)

---

## Missing Data Patterns

### CPHS Borrowing Outcomes
- Missing values: <1% for main borrowing sources
- Primarily due to:
  - New household entrants to panel (no prior wave)
  - Household panel attrition
  - Non-response to borrowing questions (rare)

### NRLM Treatment Variable
- Missing values: None; state-year coverage is complete (30 states × 6 years)

### Control Variables
- Income: ~2% missing (imputed with state-year median in analysis)
- Age, education, household size: <1% missing
- Occupation dummies: <1% missing (coded as "other" if missing)

---

## Data Quality Checks

### Borrowing Outcome Consistency
- Check: borrow_formal = borrow_bank + borrow_shg + borrow_mfi + ... (approx. match)
- Most households have 0–2 active borrowing sources (common pattern in rural India)

### SHG Intensity Trends
- All states show positive or flat SHG intensity from 2017–2022
- No sudden drops (suggesting no data quality issues)
- Within-state correlation over time: r > 0.95 (consistency check)

### Control Variable Plausibility
- Education: 0–18 years (outliers checked)
- Age: 18–100+ years (few >90, likely accurate)
- Income: Checked for extreme outliers; none removed (inequality in rural India is high)

---

## Known Limitations

1. **Individual SHG Membership Unknown**: CPHS does not identify individual SHG members, so analysis operates at state exposure level (intent-to-treat)

2. **No Loan Application/Approval Data**: CPHS does not record loan applications or rejections; only realized borrowing is observed

3. **Panel Attrition**: Some households exit the panel over time (typical in household surveys); IPW correction recommended

4. **State-Level Treatment**: NRLM data available only at state-year level, not district-year (coarser than ideal)

---

## Suggested Citation

If you use this dataset or codebook, cite as:

> Gupta, A. (2026). Do Self-Help Groups Help Women Stay in the Formal Credit System? 
> Data and codebook. Available at: https://github.com/[USERNAME]/shg-credit-persistence

---

**Codebook Last Updated**: April 2026  
**Data Period Covered**: 2017–2022
